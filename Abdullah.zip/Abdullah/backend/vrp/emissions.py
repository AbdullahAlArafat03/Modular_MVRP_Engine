def estimate_emissions(total_km, co2_per_km=0.35):
    return total_km * co2_per_km
