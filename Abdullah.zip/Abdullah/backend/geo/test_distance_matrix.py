import os
from dotenv import load_dotenv
from vrp.models import VRPRequest
from vrp.config import API_KEY

load_dotenv()
API_key = os.getenv("API_KEY")
